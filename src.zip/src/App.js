import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Layout from "./layer1";
import Home from "./Home";
import About from "./About";
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout/>}/>
          <Route path="/home" element={<Home/>}/>
          <Route path="/about" element={<About/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

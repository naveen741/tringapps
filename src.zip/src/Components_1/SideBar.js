import './SideBar.css';
export default function SideBar(){
    return (
        <div className="sideBar">
            <h2 className='items menu'>Menu</h2>
            <h3 className='items'>Home</h3>
            <h3 className='items'>Contact us</h3>
            <h3 className='items'>About</h3>
        </div>
    );
}
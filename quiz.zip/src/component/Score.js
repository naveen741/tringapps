export default function Score(props){
    return(
        <div className="score" style={{display: props.toScore}}>
            <h1>Quiz</h1>
            {
                props.questions.map((data)=>(
                    <div>
                        <div>{data.question}</div>
                        <div>
                            { 
                                data.options.map((option)=>{
                                    let color;
                                    if(option==data.selectedOption){
                                        if(option==data.correct_answer){
                                            color="green";
                                        }
                                        else{
                                            color="red";
                                        }
                                    }
                                    return(
                                    <button style={{background: color}} onClick={(evt)=>props.getAnswer(evt,option,data)}>{option}</button>
                                )})
                            }
                        </div>
                    </div>
                ))
            }
            <button onClick={()=>props.onScore("none")}>Play Again</button>
        </div>
    );
}
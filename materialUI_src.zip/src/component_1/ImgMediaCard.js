import * as React from 'react';
import './ImgMediaCard.css'
import Cards from './Cards';

export default function ImgMediaCard(props) {
  // const [val,setVal]=React.useState([""]);  
  // if(props.Output != undefined){
  //   setVal(props.Output);
    // console.log(props.Output);
  // }
  return (
    <div className='Cards'>
      {
      props.Output.map((detail)=>(
          <Cards details={detail}/>        
      ))} 
    
    </div>
  );
}
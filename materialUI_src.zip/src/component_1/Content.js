import './Content.css';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import { FormControl,FormControlLabel, FormLabel, RadioGroup, Radio } from '@mui/material';
import ImgMediaCard from './ImgMediaCard';
const ans=[];
let i=0;
export default function Content(){
    const [name, setName]=useState("");
    const [desc,setDesc]=useState("");
    const [output,setOutput]=useState([]);
    const [detail, setDetail]=useState({
        id: i,
        Name: {name},
        Description: {desc}
    });
    const onUserSubmit=(event)=>{
        event.preventDefault();
        i++;
        ans.push({detail})
        setOutput(ans);
        setDesc("");
        setName("");
        
    };
    return(
        <div  className='container'>
        <div className="content">
            <h2>Contents</h2>
            <form className='myform' id='form_1'  onSubmit={onUserSubmit} >
            <FormControl>
            <br/>
                <TextField
                    required
                    id="ProjectName"
                    label="Project Name"
                    placeholder='Enter the Project Name'
                    value={name}
                    onChange={(e)=>{setName(e.target.value ); setDetail({
                        id: i,
                        Name: {name},
                        Description: {desc}
                    });}}
                /><br/>
                
                <TextField
                    id="description"
                    label="Project Description"
                    multiline
                    value={desc}
                    rows={4}
                    onChange={(e)=>{ setDesc(e.target.value); setDetail({
                        id: i,
                        Name: {name},
                        Description: {desc}
                    });}}
                    required
                    placeholder='Enter the Project Description'
                /><br/>
                <FormLabel id="projectType">Project Type</FormLabel>
                <RadioGroup
                    aria-labelledby="projectType"
                    name="domain" >
                    <FormControlLabel  value="Android" control={<Radio required/>} label="Android" />
                    <FormControlLabel value="IOS" control={<Radio required/>} label="IOS" />
                </RadioGroup>
                <br/>
                <Button variant='contained' type='submit'>Submit</Button>
            </FormControl>    
            </form>
        </div>
        <ImgMediaCard Output={output}/>
        </div>
    );
}